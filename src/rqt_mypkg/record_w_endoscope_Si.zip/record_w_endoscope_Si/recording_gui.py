import time
import threading
from datetime import datetime
import os
import signal

import cv2
import customtkinter as ctk
import tkinter as tk
import rospy
from std_msgs.msg import String
from ros_topics_handler import ROSTopics

from utils import start_image_savers, stop_image_savers, save_images_to_queues, save_kinematics_to_csv

class RecordingAutonomousCholecApp:
    def __init__(self, root, desired_image_res=None, num_workers=4):
        """
        Parameters:
        - root: tkinter root object
        - desired_image_res: tuple of ints (width, height) for the desired image resolution or None for the default resolution of each camera
        - num_workers: number of worker threads for saving images
        """
        
        # ----------------- ROS -----------------
        
        # Initialize ROS node
        print("Initializing ROS node...")
        rospy.init_node('surgical_phases_recorder', anonymous=True)
        print("ROS node initialized.")

        self.rt = ROSTopics()
        time.sleep(0.5)

        self.phase_pub = rospy.Publisher('phase_transition', String, queue_size=10)
        print("ROS publisher created.")

        # ----------------- GUI -----------------

        self.root = root
        self.root.title("Surgical Phases Recorder")

        # Set the appearance mode of customtkinter
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        # Configure grid weights for resizing
        for col_idx in range(4):
            root.grid_columnconfigure(col_idx, weight=1)

        # Label for phases listbox
        self.phases_label = ctk.CTkLabel(root, text="Phases to record", font=ctk.CTkFont(size=15, weight="bold"))
        self.phases_label.grid(row=0, column=0, columnspan=4, pady=(10, 0))

        # List of phases to record
        self.phases_listbox = tk.Listbox(root, height=15, bg="white", fg="black")
        self.phases_listbox.grid(row=1, column=0, columnspan=4, pady=10, padx=10, sticky='nsew')

        # Available phases dropdown menu
        # TODO: Add here all possible phases - from Grabing the Gallbladder, .., to all correction phases
        self.available_phases = ["First clip duct", "Second clip duct", "Third clip duct", 
                                 "First clip artery", "Second clip artery", "Third clip artery"]
        self.phase_var = tk.StringVar(value=self.available_phases[0])
        self.phases_dropdown = ctk.CTkComboBox(root, values=self.available_phases, variable=self.phase_var, width=300)
        self.phases_dropdown.grid(row=2, column=0, padx=10, pady=(0, 10), sticky='w')

        # Add and Clear buttons
        self.add_button = ctk.CTkButton(root, text="Add", command=self.add_phase)
        self.add_button.grid(row=2, column=1, padx=20, pady=(0, 10), sticky='w')

        self.clear_button = ctk.CTkButton(root, text="Clear all", command=self.clear_phases)
        self.clear_button.grid(row=2, column=2, padx=20, pady=(0, 10), sticky='e')

        # Start/Stop recording button
        self.record_button = ctk.CTkButton(root, text="Start recording", command=self.toggle_recording)
        self.record_button.grid(row=3, column=0, pady=10, padx=10, sticky='w')

        # Trigger phase transition button
        self.transition_button = ctk.CTkButton(root, text="Trigger phase transition", command=self.trigger_transition)
        self.transition_button.grid(row=3, column=1, columnspan=3, pady=10, padx=10, sticky='e')
        self.transition_button.configure(state=tk.DISABLED)  # Initially disable the transition button

        # ----------------- Variables -----------------

        self.desired_image_res = desired_image_res
        self.recording_flag = False
        self.start_time = None
        self.current_phase_index = 0
        self.current_phase_frame_idx = 0
        self.new_recording_flag = True
        self.end_of_recording_flag = False
        self.phase_transition_triggered_flag = False
        self.ee_points = []

        # ----------------- Starting recording threads -----------------

        self.image_queues, self.workers = start_image_savers(num_workers)

        self.main_loop_thread = threading.Thread(target=self.main_loop)
        self.main_loop_thread.daemon = True
        self.main_loop_thread.start()

        # Set up signal handler for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)

    def add_phase(self):
        phase = self.phase_var.get()
        if phase:
            self.phases_listbox.insert(tk.END, phase)

    def clear_phases(self):
        self.phases_listbox.delete(0, tk.END)
        self.current_phase_index = 0

    def toggle_recording(self):
        if self.recording_flag:
            self.record_button.configure(text="Start recording")
            rospy.loginfo("Recording stopped")
            self.transition_button.configure(state=tk.DISABLED) # Disable transition button
            self.clear_button.configure(state=tk.NORMAL) # Enable clear button
            self.add_button.configure(state=tk.NORMAL) # Enable add button
            self.current_phase_index = 0
            self.end_of_recording_flag = True
        else:
            self.record_button.configure(text="Stop recording")
            rospy.loginfo("Recording started")
            self.start_time = time.time()
            if self.phases_listbox.size() > 1:
                self.transition_button.configure(state=tk.NORMAL) # Enable transition button
            self.clear_button.configure(state=tk.DISABLED) # Disable clear button
            self.add_button.configure(state=tk.DISABLED) # Disable add button
        
        self.recording_flag = not self.recording_flag
        self.update_phase_highlight() # If recording, highlight the current phase - otherwise reset highlighting

    def trigger_transition(self):
        phases = self.phases_listbox.get(0, tk.END)
        self.phase_transition_triggered_flag = True
        
        # Transition to the next phase
        current_phase = phases[self.current_phase_index]
        next_phase = phases[self.current_phase_index + 1]
        timestamp = time.time() - self.start_time
        msg = f"Transition from {current_phase} to {next_phase} at time {timestamp:.2f} seconds"
        rospy.loginfo(msg)
        self.phase_pub.publish(msg)
        
        if self.current_phase_index == len(phases) - 2:
            self.transition_button.configure(state=tk.DISABLED)
        
        self.current_phase_index += 1
        self.update_phase_highlight()

    def update_phase_highlight(self):
        for phase_list_idx in range(self.phases_listbox.size()):
            self.phases_listbox.itemconfig(phase_list_idx, {'bg': 'white', 'fg': 'black'})
        if self.recording_flag and self.current_phase_index < self.phases_listbox.size():
            self.phases_listbox.itemconfig(self.current_phase_index, {'bg': 'lightblue', 'fg': 'black'})

    def main_loop(self):
        rate = rospy.Rate(30)  # ROS Rate at 30Hz
        
        recordings_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "_recordings")
        
        while not rospy.is_shutdown():
            if self.recording_flag:
                if self.new_recording_flag:
                    # Save the data into separate folders for each phase (if phase(s) defined)
                    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
                    if self.phases_listbox.size() > 0:
                        current_state = self.phases_listbox.get(self.current_phase_index)
                        self.episode_dir = os.path.join(recordings_dir, current_state, timestamp)
                    else:
                        self.episode_dir = os.path.join(recordings_dir, timestamp)
                    
                    # Reset variables
                    self.new_recording_flag = False
                    self.current_phase_frame_idx = 0
                    self.ee_points = []
                elif self.phase_transition_triggered_flag:
                    # Save the kinematics to a CSV file
                    save_kinematics_to_csv(self.rt, self.ee_points, self.episode_dir)
                    
                    # Update the episode directory -> use the recording start timestamp
                    if self.phases_listbox.size() > 0:
                        current_state = self.phases_listbox.get(self.current_phase_index)
                        self.episode_dir = os.path.join(recordings_dir, current_state, timestamp)
                    else:
                        self.episode_dir = os.path.join(recordings_dir, timestamp)
                    
                    # Reset variables
                    self.phase_transition_triggered_flag = False
                    self.current_phase_frame_idx = 0
                    self.ee_points = []

                # Collecting current end-effector points 
                current_kinematics = self.rt.get_current_kinematics()
                self.ee_points.append(current_kinematics)

                # Save frames
                images_dict = self.rt.get_images_and_path_dict(self.episode_dir, self.current_phase_frame_idx, self.desired_image_res)
                save_images_to_queues(self.image_queues, images_dict)
                self.current_phase_frame_idx += 1
            else:
                # Save the kinematics to a CSV file
                if self.end_of_recording_flag:
                    save_kinematics_to_csv(self.rt, self.ee_points, self.episode_dir)
                    self.end_of_recording_flag = False

                # Reset variables
                self.new_recording_flag = True

            rate.sleep() # TODO: Check the processing time + return value

        cv2.destroyAllWindows()
        stop_image_savers(self.workers, self.image_queues)

    def signal_handler(self, sig, frame):
        print("Ctrl+C detected, shutting down gracefully...")
        self.root.quit()  # Close the GUI
        rospy.signal_shutdown("Ctrl+C detected")

if __name__ == "__main__":
    print("Starting application...")
    root = ctk.CTk()
    desired_image_res = (640, 480)
    num_workers = 4
    app = RecordingAutonomousCholecApp(root, desired_image_res, num_workers)
    root.mainloop()
    print("Application running.")
    # TODO: Add info when either GUI or ros stopped and stop then the other one
