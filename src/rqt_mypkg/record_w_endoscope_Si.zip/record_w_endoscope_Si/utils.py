import os
import threading
import queue

import pandas as pd
import cv2

# ----------------- Kinematics Saver -----------------

def save_kinematics_to_csv(rt, ee_points, episode_dir):
    kinematics_df_header = rt.get_kinematics_df_header()
    csv_data = pd.DataFrame(ee_points)
    ee_save_path = os.path.join(episode_dir, "kinematics.csv")
    csv_data.to_csv(ee_save_path, index=False, header=kinematics_df_header)
    print(f"Saved kinematics to {ee_save_path}")

# ----------------- Image Saver -----------------

def image_saver(image_queue):
    while True:
        item = image_queue.get()
        if item is None:
            break  # None is our signal to stop
        filename, image = item
        
        # Create the folder if it doesn't exist
        folder_dir = os.path.dirname(filename)
        os.makedirs(folder_dir, exist_ok=True)
        
        # Save the image
        cv2.imwrite(filename, image)
        image_queue.task_done()

def start_image_savers(num_workers):
    image_queues = [queue.Queue() for _ in range(num_workers)]
    workers = []
    for q in image_queues:
        worker = threading.Thread(target=image_saver, args=(q,))
        worker.start()
        workers.append(worker)
    return image_queues, workers

def stop_image_savers(workers, image_queues):
    for q in image_queues:
        q.put(None)  # Signal the worker threads to stop
    for worker in workers:
        worker.join()

def save_images_to_queues(queues, image_dict):    
    # Distribute the images to the queues with the smallest workload (without replacement)
    queues_with_smallest_workload = get_queues_with_smallest_workload(queues, len(image_dict))
    for queue, (file_path, img) in zip(queues_with_smallest_workload, image_dict.items()):
        queue.put((file_path, img))

# TODO: Check if this works - does this slow it down more than gives us benefit?
def get_queues_with_smallest_workload(queues, num_req_queues):
    queue_lengths = [q.qsize() for q in queues]
    sorted_indices = sorted(range(len(queue_lengths)), key=lambda idx: queue_lengths[idx])
    
    lowest_queues = []
    i = 0
    while len(lowest_queues) < num_req_queues:
        # Select the current queue index
        current_q_index = sorted_indices[i]
        current_queue_size = queue_lengths[current_q_index]
        
        # If we are at the last index, we just add this queue until we have enough queues
        if i == len(sorted_indices) - 1:
            lowest_queues.extend([queues[current_q_index]] * (num_req_queues - len(lowest_queues)))
        else:
            next_q_index = sorted_indices[i + 1]
            next_queue_size = queue_lengths[next_q_index]
            workload_difference = next_queue_size - current_queue_size
            
            # Add the current queue as many times as the workload difference allows, or until we have enough queues
            add_count = min(workload_difference, num_req_queues - len(lowest_queues))
            lowest_queues.extend([queues[current_q_index]] * add_count)
        
        i += 1
    
    return lowest_queues