import os

import rospy
from sensor_msgs.msg import Image, JointState
from geometry_msgs.msg import PoseStamped
from cv_bridge import CvBridge
import cv2


class ROSTopics:
    def __init__(self):
        # ROS variables
        self.da_vinci_image_left = self.da_vinci_image_right = self.endo_cam_psm1 = self.endo_cam_psm2 = None
        self.psm1_pose = self.psm1_sp = self.psm1_rcm_pose = self.psm1_jaw = self.psm1_jaw_sp = None
        self.psm2_pose = self.psm2_sp = self.psm2_rcm_pose = self.psm2_jaw = self.psm2_jaw_sp = None
        self.ecm_pose = self.ecm_rcm_pose = None
        self.suj1_pose = self.suj1_jp = self.suj2_pose = self.suj2_jp = self.suj3_pose = self.suj3_jp = self.suj_ecm_pose = self.suj_ecm_jp = None # E.g., SUJ/PSM1/measured_cp, measured_js
        self.psm1_js = self.psm1_set_js = self.psm2_js = self.psm2_set_js = self.psm3_js = self.psm3_set_js = self.ecm_js = self.ecm_set_js = None # E.g., PSM1/measured_js, setpoint_js
        
        # Setup ROS bridge for image conversion
        self.bridge = CvBridge()
        
        # Subscribe to topics
        self.subscribe_to_topics()

    def subscribe_to_topics(self):
        # ecm endoscopes imgs
        self.da_vinci_camera_left_sub = rospy.Subscriber("/jhu_daVinci/left/image_raw", Image, self.get_camera_image_left)
        self.da_vinci_camera_right_sub = rospy.Subscriber("/jhu_daVinci/right/image_raw", Image, self.get_camera_image_right)
        
        # wrist endoscope imgs
        self.endo_cam_psm1_sub = rospy.Subscriber("/PSM1/endoscope_img", Image, self.get_endo_cam_psm1)
        self.endo_cam_psm2_sub = rospy.Subscriber("/PSM2/endoscope_img", Image, self.get_endo_cam_psm2)

        # psm1
        self.psm1_sub = rospy.Subscriber("/PSM1/measured_cp", PoseStamped, self.get_psm1_pose)
        self.psm1_sp_sub = rospy.Subscriber("/PSM1/setpoint_cp", PoseStamped, self.get_psm1_setpoint)
        self.psm1_rcm_sub = rospy.Subscriber("PSM1/local/measured_cp", PoseStamped, self.get_psm1_rcm_pose)
        self.psm1_jaw_sub = rospy.Subscriber("PSM1/jaw/measured_js", JointState, self.get_psm1_jaw)
        self.psm1_jaw_sp_sub = rospy.Subscriber("PSM1/jaw/setpoint_js", JointState, self.get_psm1_jaw_sp)

        # psm2
        self.psm2_sub = rospy.Subscriber("/PSM2/measured_cp", PoseStamped, self.get_psm2_pose)    
        self.psm2_sp_sub = rospy.Subscriber("/PSM2/setpoint_cp", PoseStamped, self.get_psm2_setpoint)
        self.psm2_rcm_sub = rospy.Subscriber("PSM2/local/measured_cp", PoseStamped, self.get_psm2_rcm_pose)
        self.psm2_jaw_sub = rospy.Subscriber("PSM2/jaw/measured_js", JointState, self.get_psm2_jaw)
        self.psm2_jaw_sp_sub = rospy.Subscriber("PSM2/jaw/setpoint_js", JointState, self.get_psm2_jaw_sp)

        # TODO: Add later PSM3 (if needed)

        # ecm
        self.ecm_sub = rospy.Subscriber("/ECM/measured_cp", PoseStamped, self.get_ecm_pose)
        self.ecm_rcm_sub = rospy.Subscriber("ECM/local/measured_cp", PoseStamped, self.get_ecm_rcm_pose)
        
        # sujs
        self.sub1 = rospy.Subscriber("/SUJ/PSM1/measured_cp", PoseStamped, self.c1)
        self.sub2 = rospy.Subscriber("/SUJ/PSM1/measured_js", JointState, self.c2)
        self.sub3 = rospy.Subscriber("/SUJ/PSM2/measured_cp", PoseStamped, self.c3)
        self.sub4 = rospy.Subscriber("/SUJ/PSM2/measured_js", JointState, self.c4)
        self.sub5 = rospy.Subscriber("/SUJ/PSM3/measured_cp", PoseStamped, self.c5)
        self.sub6 = rospy.Subscriber("/SUJ/PSM3/measured_js", JointState, self.c6)
        self.sub7 = rospy.Subscriber("/SUJ/ECM/measured_cp", PoseStamped, self.c7)
        self.sub8 = rospy.Subscriber("/SUJ/ECM/measured_js", JointState, self.c8)
        
        # psms js
        self.sub9 = rospy.Subscriber("/PSM1/measured_js", JointState, self.c9)
        self.sub10 = rospy.Subscriber("/PSM1/setpoint_js", JointState, self.c10)
        self.sub11 = rospy.Subscriber("/PSM2/measured_js", JointState, self.c11)
        self.sub12 = rospy.Subscriber("/PSM2/setpoint_js", JointState, self.c12)
        self.sub13 = rospy.Subscriber("/PSM3/measured_js", JointState, self.c13)
        self.sub14 = rospy.Subscriber("/PSM3/setpoint_js", JointState, self.c14)
        self.sub15 = rospy.Subscriber("/ECM/measured_js", JointState, self.c15)
        self.sub16 = rospy.Subscriber("/ECM/setpoint_js", JointState, self.c16)
        
    def get_current_kinematics(self):
        current_kinematics = [
            # PSM1
            self.psm1_pose.position.x, self.psm1_pose.position.y, self.psm1_pose.position.z,
            self.psm1_pose.orientation.x, self.psm1_pose.orientation.y, self.psm1_pose.orientation.z, self.psm1_pose.orientation.w,
            self.psm1_sp.position.x, self.psm1_sp.position.y, self.psm1_sp.position.z,
            self.psm1_sp.orientation.x, self.psm1_sp.orientation.y, self.psm1_sp.orientation.z, self.psm1_sp.orientation.w,
            self.psm1_jaw, self.psm1_jaw_sp,
            self.psm1_rcm_pose.position.x, self.psm1_rcm_pose.position.y, self.psm1_rcm_pose.position.z,
            self.psm1_rcm_pose.orientation.x, self.psm1_rcm_pose.orientation.y, self.psm1_rcm_pose.orientation.z, self.psm1_rcm_pose.orientation.w,
            # PSM2
            self.psm2_pose.position.x, self.psm2_pose.position.y, self.psm2_pose.position.z,
            self.psm2_pose.orientation.x, self.psm2_pose.orientation.y, self.psm2_pose.orientation.z, self.psm2_pose.orientation.w,
            self.psm2_sp.position.x, self.psm2_sp.position.y, self.psm2_sp.position.z,
            self.psm2_sp.orientation.x, self.psm2_sp.orientation.y, self.psm2_sp.orientation.z, self.psm2_sp.orientation.w,
            self.psm2_jaw, self.psm2_jaw_sp,
            self.psm2_rcm_pose.position.x, self.psm2_rcm_pose.position.y, self.psm2_rcm_pose.position.z,
            self.psm2_rcm_pose.orientation.x, self.psm2_rcm_pose.orientation.y, self.psm2_rcm_pose.orientation.z, self.psm2_rcm_pose.orientation.w,
            # ECM
            self.ecm_pose.position.x, self.ecm_pose.position.y, self.ecm_pose.position.z,
            self.ecm_pose.orientation.x, self.ecm_pose.orientation.y, self.ecm_pose.orientation.z, self.ecm_pose.orientation.w,
            self.ecm_rcm_pose.position.x, self.ecm_rcm_pose.position.y, self.ecm_rcm_pose.position.z,
            self.ecm_rcm_pose.orientation.x, self.ecm_rcm_pose.orientation.y, self.ecm_rcm_pose.orientation.z, self.ecm_rcm_pose.orientation.w,
            # suj poses
            self.suj1_pose.position.x, self.suj1_pose.position.y, self.suj1_pose.position.z,
            self.suj1_pose.orientation.x, self.suj1_pose.orientation.y, self.suj1_pose.orientation.z, self.suj1_pose.orientation.w,
            self.suj1_jp[0], self.suj1_jp[1], self.suj1_jp[2], self.suj1_jp[3],
            self.suj2_pose.position.x, self.suj2_pose.position.y, self.suj2_pose.position.z,
            self.suj2_pose.orientation.x, self.suj2_pose.orientation.y, self.suj2_pose.orientation.z, self.suj2_pose.orientation.w,
            self.suj2_jp[0], self.suj2_jp[1], self.suj2_jp[2], self.suj2_jp[3],
            self.suj3_pose.position.x, self.suj3_pose.position.y, self.suj3_pose.position.z,
            self.suj3_pose.orientation.x, self.suj3_pose.orientation.y, self.suj3_pose.orientation.z, self.suj3_pose.orientation.w,
            self.suj3_jp[0], self.suj3_jp[1], self.suj3_jp[2], self.suj3_jp[3],
            self.suj_ecm_pose.position.x, self.suj_ecm_pose.position.y, self.suj_ecm_pose.position.z,
            self.suj_ecm_pose.orientation.x, self.suj_ecm_pose.orientation.y, self.suj_ecm_pose.orientation.z, self.suj_ecm_pose.orientation.w,
            self.suj_ecm_jp[0], self.suj_ecm_jp[1], self.suj_ecm_jp[2], self.suj_ecm_jp[3],
            self.psm1_js[0], self.psm1_js[1], self.psm1_js[2], self.psm1_js[3], self.psm1_js[4], self.psm1_js[5],
            self.psm1_set_js[0], self.psm1_set_js[1], self.psm1_set_js[2], self.psm1_set_js[3], self.psm1_set_js[4], self.psm1_set_js[5],
            self.psm2_js[0], self.psm2_js[1], self.psm2_js[2], self.psm2_js[3], self.psm2_js[4], self.psm2_js[5],
            self.psm2_set_js[0], self.psm2_set_js[1], self.psm2_set_js[2], self.psm2_set_js[3], self.psm2_set_js[4], self.psm2_set_js[5],
            self.psm3_js[0], self.psm3_js[1], self.psm3_js[2], self.psm3_js[3], self.psm3_js[4], self.psm3_js[5],
            self.psm3_set_js[0], self.psm3_set_js[1], self.psm3_set_js[2], self.psm3_set_js[3], self.psm3_set_js[4], self.psm3_set_js[5],
            self.ecm_js[0], self.ecm_js[1], self.ecm_js[2], self.ecm_js[3],
            self.ecm_set_js[0], self.ecm_set_js[1], self.ecm_set_js[2], self.ecm_set_js[3]
        ]
        return current_kinematics

    def get_kinematics_df_header(self):
        kinematics_df_header = [
            "psm1_pose.position.x", "psm1_pose.position.y", "psm1_pose.position.z",
            "psm1_pose.orientation.x", "psm1_pose.orientation.y", "psm1_pose.orientation.z", "psm1_pose.orientation.w",
            "psm1_sp.position.x", "psm1_sp.position.y", "psm1_sp.position.z",
            "psm1_sp.orientation.x", "psm1_sp.orientation.y", "psm1_sp.orientation.z", "psm1_sp.orientation.w",
            "psm1_jaw", "psm1_jaw_sp",
            "psm1_rcm_pose.position.x", "psm1_rcm_pose.position.y", "psm1_rcm_pose.position.z",
            "psm1_rcm_pose.orientation.x", "psm1_rcm_pose.orientation.y", "psm1_rcm_pose.orientation.z", "psm1_rcm_pose.orientation.w",
            "psm2_pose.position.x", "psm2_pose.position.y", "psm2_pose.position.z",
            "psm2_pose.orientation.x", "psm2_pose.orientation.y", "psm2_pose.orientation.z", "psm2_pose.orientation.w",
            "psm2_sp.position.x", "psm2_sp.position.y", "psm2_sp.position.z",
            "psm2_sp.orientation.x", "psm2_sp.orientation.y", "psm2_sp.orientation.z", "psm2_sp.orientation.w",
            "psm2_jaw", "psm2_jaw_sp",
            "psm2_rcm_pose.position.x", "psm2_rcm_pose.position.y", "psm2_rcm_pose.position.z",
            "psm2_rcm_pose.orientation.x", "psm2_rcm_pose.orientation.y", "psm2_rcm_pose.orientation.z", "psm2_rcm_pose.orientation.w",
            "ecm_pose.position.x", "ecm_pose.position.y", "ecm_pose.position.z",
            "ecm_pose.orientation.x", "ecm_pose.orientation.y", "ecm_pose.orientation.z", "ecm_pose.orientation.w",
            "ecm_rcm_pose.position.x", "ecm_rcm_pose.position.y", "ecm_rcm_pose.position.z",
            "ecm_rcm_pose.orientation.x", "ecm_rcm_pose.orientation.y", "ecm_rcm_pose.orientation.z", "ecm_rcm_pose.orientation.w",
            "suj1_pose.position.x", "suj1_pose.position.y", "suj1_pose.position.z",
            "suj1_pose.orientation.x", "suj1_pose.orientation.y", "suj1_pose.orientation.z", "suj1_pose.orientation.w",
            "suj1_jp[0]", "suj1_jp[1]", "suj1_jp[2]", "suj1_jp[3]",
            "suj2_pose.position.x", "suj2_pose.position.y", "suj2_pose.position.z",
            "suj2_pose.orientation.x", "suj2_pose.orientation.y", "suj2_pose.orientation.z", "suj2_pose.orientation.w",
            "suj2_jp[0]", "suj2_jp[1]", "suj2_jp[2]", "suj2_jp[3]",
            "suj3_pose.position.x", "suj3_pose.position.y", "suj3_pose.position.z",
            "suj3_pose.orientation.x", "suj3_pose.orientation.y", "suj3_pose.orientation.z", "suj3_pose.orientation.w",
            "suj3_jp[0]", "suj3_jp[1]", "suj3_jp[2]", "suj3_jp[3]",
            "suj_ecm_pose.position.x", "suj_ecm_pose.position.y", "suj_ecm_pose.position.z",
            "suj_ecm_pose.orientation.x", "suj_ecm_pose.orientation.y", "suj_ecm_pose.orientation.z", "suj_ecm_pose.orientation.w",
            "suj_ecm_jp[0]", "suj_ecm_jp[1]", "suj_ecm_jp[2]", "suj_ecm_jp[3]",
            "psm1_js[0]", "psm1_js[1]", "psm1_js[2]", "psm1_js[3]", "psm1_js[4]", "psm1_js[5]",
            "psm1_set_js[0]", "psm1_set_js[1]", "psm1_set_js[2]", "psm1_set_js[3]", "psm1_set_js[4]", "psm1_set_js[5]",
            "psm2_js[0]", "psm2_js[1]", "psm2_js[2]", "psm2_js[3]", "psm2_js[4]", "psm2_js[5]",
            "psm2_set_js[0]", "psm2_set_js[1]", "psm2_set_js[2]", "psm2_set_js[3]", "psm2_set_js[4]", "psm2_set_js[5]",
            "psm3_js[0]", "psm3_js[1]", "psm3_js[2]", "psm3_js[3]", "psm3_js[4]", "psm3_js[5]",
            "psm3_set_js[0]", "psm3_set_js[1]", "psm3_set_js[2]", "psm3_set_js[3]", "psm3_set_js[4]", "psm3_set_js[5]",
            "ecm_js[0]", "ecm_js[1]", "ecm_js[2]", "ecm_js[3]",
            "ecm_set_js[0]", "ecm_set_js[1]", "ecm_set_js[2]", "ecm_set_js[3]"
            ]
        
        return kinematics_df_header

    def get_images_and_path_dict(self, episode_dir, num_frames, desired_image_res):
        
        # Copy the images to avoid modifying the original images
        da_vinci_image_left_transformed = self.da_vinci_image_left.copy()
        da_vinci_image_right_transformed = self.da_vinci_image_right.copy()
        endo_cam_psm1_transformed = self.endo_cam_psm1.copy()
        endo_cam_psm2_transformed = self.endo_cam_psm2.copy()
        
        # Resize the images if the desired resolution is not None and the images are not already in the desired resolution
        if desired_image_res is not None and self.da_vinci_image_left.shape[:2] != desired_image_res:
            da_vinci_image_left_transformed = cv2.resize(self.da_vinci_image_left, desired_image_res)
        if desired_image_res is not None and self.da_vinci_image_right.shape[:2] != desired_image_res:
            da_vinci_image_right_transformed = cv2.resize(self.da_vinci_image_right, desired_image_res)
        if desired_image_res is not None and self.endo_cam_psm1.shape[:2] != desired_image_res:
            endo_cam_psm1_transformed = cv2.resize(self.endo_cam_psm1, desired_image_res)
        if desired_image_res is not None and self.endo_cam_psm2.shape[:2] != desired_image_res:
            endo_cam_psm2_transformed = cv2.resize(self.endo_cam_psm2, desired_image_res)
        
        # Convert the DaVinci images to RGB
        da_vinci_image_left_transformed = cv2.cvtColor(da_vinci_image_left_transformed, cv2.COLOR_BGR2RGB)
        da_vinci_image_right_transformed = cv2.cvtColor(da_vinci_image_right_transformed, cv2.COLOR_BGR2RGB)
        
        # Save an images-to-saving-path mapping 
        images_and_path_dict = {}
        images = [da_vinci_image_left_transformed, da_vinci_image_right_transformed, endo_cam_psm1_transformed, endo_cam_psm2_transformed]
        image_dirs = ["left_img_dir", "right_img_dir", "psm1_img_dir", "psm2_img_dir"]
        for image, image_dir in zip(images, image_dirs):
            file_path = os.path.join(episode_dir, image_dir, f"frame_{num_frames:06d}_{image_dir.split('_')[0]}.png")
            images_and_path_dict[file_path] = image
        
        return images_and_path_dict

    # ------------------- Callbacks -------------------

    # TODO: Check how to readout the timestamps for the wrist cameras, endoscope images, and the kinematics

    def get_camera_image_left(self, data):
        self.da_vinci_image_left = self.bridge.imgmsg_to_cv2(data, desired_encoding='passthrough')

    def get_camera_image_right(self, data):
        self.da_vinci_image_right = self.bridge.imgmsg_to_cv2(data, desired_encoding='passthrough')

    def get_endo_cam_psm1(self, data):
        self.endo_cam_psm1 = self.bridge.imgmsg_to_cv2(data, desired_encoding='passthrough')

    def get_endo_cam_psm2(self, data):
        self.endo_cam_psm2 = self.bridge.imgmsg_to_cv2(data, desired_encoding='passthrough')

    def get_ecm_pose(self, data):
        self.ecm_pose = data.pose

    def get_ecm_rcm_pose(self, data):
        self.ecm_rcm_pose = data.pose

    def get_psm1_pose(self, data):
        self.psm1_pose = data.pose

    def get_psm1_setpoint(self, data):
        self.psm1_sp = data.pose

    def get_psm1_rcm_pose(self, data):
        self.psm1_rcm_pose = data.pose

    def get_psm2_pose(self, data):
        self.psm2_pose = data.pose

    def get_psm2_setpoint(self, data):
        self.psm2_sp = data.pose

    def get_psm2_rcm_pose(self, data):
        self.psm2_rcm_pose = data.pose

    def get_psm1_jaw(self, data):
        self.psm1_jaw = data.position[0]

    def get_psm1_jaw_sp(self, data):
        self.psm1_jaw_sp = data.position[0]

    def get_psm2_jaw(self, data):
        self.psm2_jaw = data.position[0]

    def get_psm2_jaw_sp(self, data):
        self.psm2_jaw_sp = data.position[0]

    def c1(self, data):
        self.suj1_pose = data.pose

    def c2(self, data):
        self.suj1_jp = data.position

    def c3(self, data):
        self.suj2_pose = data.pose

    def c4(self, data):
        self.suj2_jp = data.position

    def c5(self, data):
        self.suj3_pose = data.pose

    def c6(self, data):
        self.suj3_jp = data.position

    def c7(self, data):
        self.suj_ecm_pose = data.pose

    def c8(self, data):
        self.suj_ecm_jp = data.position

    def c9(self, data):
        self.psm1_js = data.position

    def c10(self, data):
        self.psm1_set_js = data.position

    def c11(self, data):
        self.psm2_js = data.position

    def c12(self, data):
        self.psm2_set_js = data.position

    def c13(self, data):
        self.psm3_js = data.position

    def c14(self, data):
        self.psm3_set_js = data.position

    def c15(self, data):
        self.ecm_js = data.position

    def c16(self, data):
        self.ecm_set_js = data.position