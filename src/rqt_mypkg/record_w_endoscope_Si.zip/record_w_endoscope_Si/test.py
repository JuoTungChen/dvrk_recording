import cv2

def check_video_channels(num_channels=10):
    active_channels = []
    for i in range(num_channels):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            active_channels.append(i)
            print(f"Video channel {i} is active.")
        else:
            print(f"Video channel {i} is not active.")
        cap.release()
    return active_channels

if __name__ == "__main__":
    active_channels = check_video_channels(10)
    print("Active video channels:", active_channels)
